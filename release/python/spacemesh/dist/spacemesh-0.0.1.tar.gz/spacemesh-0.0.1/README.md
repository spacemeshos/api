# Spacemesh GRPC API

The Python build of the Spacemesh GRPC API. See
https://github.com/spacemeshos/api for more information.
